SCEditor Addon for WYSIWYG Web Builder

This installer will install SCEditor in the folder My Documents\WYSIWYG Web Builder\system\cms\sceditor so it can be used as part of the Content Management System.

http://www.sceditor.com/