TinyMCE Addon for WYSIWYG Web Builder

This installer will install TinyMCE version 3.4.4 in the folder My Documents\WYSIWYG Web Builder\system\cms\tinymce so it can be used as part of the Content Management System.

http://www.tinymce.com/