What is FTP Manager?
FTP Manager can be used to manage (upload/download/rename/delete) files and folders on a FTP server.

Key features:
Look and feel of Windows Explorer/Office 2003 products
Drag and drop support.
Multi threaded file management by using shell API for most operations.
Changes to file and folders from another programs will immediately reflected in the views of FTP Manager.
Context menus just like Windows Explorer.
Compare to contents of two folder.
Intergrated FTP client, view/open files and folder just like your local files/folders.


How to install FTP Manager?
Unzip the file into the same folder as WYSIWYG Web builder.
You can access the FTP Manager from the Tools menu in WYSIWYG Web builder.

How to use FTP Manager?
To make a connection with a FTP server, click the 'Connect'-button.
A window will popup where you can add/edit and remove FTP sites. Click 'Add' to insert a new site.
Enter the required fields (check the documentation of your webhost for more details).
Make sure you enable 'Use passive mode' if you are behind a firewall or router.
Click OK to save and next select Connect to make a connection.
Now you can drag and drop files to and from the server, just like you can do with your local files in Windows Explorer.

Keyboard Shortcuts:
F2		-	Rename file/folder
F3		-	View selected file/folder
F4		-	Edit selected file/folder
F5		-	Copy selected file/folder
F6		-	Move/Rename selected file/folder
F7		- 	Create new folder
F8		-	Delete selected file/folder
F9		-	Reserved
F10		-	Exit application
Ctrl+A		-	Select all files/folders
Alt+Enter	-	Show properties of selected file/folder
Tab		-	Switch focus between left-right panel.
Ctrl+R		- 	Refresh active panel
Alt+F1		-	Select drive for Left panel
Ctrl+F2		-	Select FTP site for Right panel
Del		-	Delete selected file/folder


� Copyright 2006 Pablo Software Solutions
http://www.pablosoftwaresolutions.com