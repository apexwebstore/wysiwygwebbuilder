Trumbowyg Addon for WYSIWYG Web Builder

This installer will install Trumbowyg in the folder My Documents\WYSIWYG Web Builder\system\cms\trumbowyg so it can be used as part of the Content Management System.

http://alex-d.github.io/Trumbowyg/