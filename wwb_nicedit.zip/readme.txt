NicEdit Addon for WYSIWYG Web Builder

This installer will install NicEdit in the folder My Documents\WYSIWYG Web Builder\system\cms\nicedit so it can be used as part of the Content Management System.

http://www.nicedit.com/