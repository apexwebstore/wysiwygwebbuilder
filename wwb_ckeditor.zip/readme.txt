CKEditor Addon for WYSIWYG Web Builder

This installer will install CKEditor version 3.6.1 in the folder My Documents\WYSIWYG Web Builder\system\cms\ckeditor so it can be used as part of the Content Management System.

http://ckeditor.com/