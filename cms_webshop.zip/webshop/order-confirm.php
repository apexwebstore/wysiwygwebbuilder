<?php
   global $db;
   if (isset($_REQUEST['order_number']))
   {
      $order_number = $_REQUEST['order_number'];
      if (get_magic_quotes_gpc())
      {
         $order_number = stripslashes($order_number);
      }
      $order_number = mysql_real_escape_string($order_number);

      $sql = "UPDATE CMS_WEBSHOP_ORDERS SET order_status = '2' WHERE order_number = '$order_number'";
      mysql_query($sql, $db) or die(mysql_error());
   }
?>