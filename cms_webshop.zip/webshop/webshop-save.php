<?php
   global $db;

   if (isset($_REQUEST['pageid']) && 
       isset($_REQUEST['product_sku']) &&
       isset($_REQUEST['product_name']) &&
       isset($_REQUEST['product_price']) &&
       isset($_REQUEST['product_shipping']) &&
       isset($_REQUEST['product_description']) &&
       isset($_REQUEST['product_details']))
   {
      $webshop_id = isset($_REQUEST['webshopid']) ? $_REQUEST['webshopid'] : -1;
      $page_id = $_REQUEST['pageid'];

      $product_sku = $_REQUEST['product_sku'];
      $product_name = $_REQUEST['product_name'];
      $product_price = floatval($_REQUEST['product_price']);
      $product_shipping = floatval($_REQUEST['product_shipping']);
      $product_description = $_REQUEST['product_description'];
      $product_details = $_REQUEST['product_details'];
      if (get_magic_quotes_gpc())
      {
         $product_sku = stripslashes($product_sku);
         $product_name = stripslashes($product_name);
         $product_description = stripslashes($product_description);
         $product_details = stripslashes($product_details);
      }
      $product_sku = mysql_real_escape_string($product_sku);
      $product_name = mysql_real_escape_string($product_name);
      $product_description = mysql_real_escape_string($product_description);
      $product_details = mysql_real_escape_string($product_details);
   
      if ($webshop_id >= 0)
      {
         $sql = "UPDATE CMS_WEBSHOP_PRODUCTS SET `product_sku` = '$product_sku', `product_name` = '$product_name', `product_price` = '$product_price', `product_shipping` = '$product_shipping', `product_description` = '$product_description', `product_details` = '$product_details', `page_id` = '$page_id' WHERE `id` = '$webshop_id'";
         mysql_query($sql, $db) or die(mysql_error());
      }
      else
      {
         $sql = "INSERT CMS_WEBSHOP_PRODUCTS (`product_sku`, `product_name`, `product_price`, `product_shipping`, `product_description`, `product_details`, `page_id`) VALUES ('$product_sku', '$product_name', '$product_price', '$product_shipping', '$product_description', '$product_details', '$page_id')";
         mysql_query($sql, $db) or die(mysql_error());
         $webshop_id = mysql_insert_id();
      } 
      echo $webshop_id;
   }
?>