<?php
   global $db;

   if (isset($_REQUEST['product_id']) && isset($_FILES['product_image']))
   {
      if ($_FILES['product_image']['name'] == '')
         return;

      $product_id = intval($_REQUEST['product_id']);
      if ($_FILES['product_image']['error'] > 0)
      {
         die("File upload error: " . $_FILES['product_image']['error']);
      }
      else
      {
         $imagespath = basename(dirname(dirname(__FILE__)))."/".basename(dirname(__FILE__))."/images/";
         if (move_uploaded_file($_FILES['product_image']['tmp_name'], $imagespath. $_FILES['product_image']['name']))
         {
            $product_image = $_FILES['product_image']['name'];
            $sql = "UPDATE CMS_WEBSHOP_PRODUCTS SET product_image = '$product_image' WHERE id = '$product_id'";
            mysql_query($sql, $db) or die(mysql_error());
         }
         else
         {
            die("File upload error: Upload failed, please verify the folder's permissions.");
         }
      }
   }
?>