<?php
   global $db;
   if (isset($_REQUEST['order_number']))
   {
      $order_number = $_REQUEST['order_number'];
      if (get_magic_quotes_gpc())
      {
         $order_number = stripslashes($order_number);
      }
      $order_number = mysql_real_escape_string($order_number);

      $sql = "DELETE FROM CMS_WEBSHOP_ORDERS WHERE order_number='$order_number'";
      mysql_query($sql, $db) or die(mysql_error());

      $sql = "DELETE FROM CMS_WEBSHOP_ORDERITEMS WHERE order_number='$order_number'";
      mysql_query($sql, $db) or die(mysql_error());
   }
?>