<?php

$plugin = array(
	'name' => 'Webshop',
	'description' => 'Webshop',
	'admin' => array(
		'init' => array('function' => 'webshop_init'),
		'update' => array('function' => 'webshop_update'),
		'tab' => array('name' => 'Webshop', 'function' => 'webshop_tab')
		),
	'events' => array('onAfterContent' => 'webshop_after_content')
	);

define("WEBSHOP_ADDTOCART", "Add to Cart");
define("WEBSHOP_VIEWCART", "View Cart");
define("WEBSHOP_OVERVIEW", "Product Overview");
define("WEBSHOP_SEARCH", "Search");
define("WEBSHOP_SEARCH_FOUND", "Found ");
define("WEBSHOP_SEARCH_RESULTS", " results for ");
define("WEBSHOP_SEARCH_NORESULTS", "No results for ");
define("WEBSHOP_CHECKOUT", "Check out");
define("WEBSHOP_PRODUCTNAME", "Product Name");
define("WEBSHOP_PRICE", "Price");
define("WEBSHOP_QUANTITY", "Quantity");
define("WEBSHOP_AMOUNT", "Amount");
define("WEBSHOP_SHIPPING", "Shipping");
define("WEBSHOP_TOTAL", "Total");
define("WEBSHOP_SKU", "SKU");
define("WEBSHOP_UPDATE", "Update");
define("WEBSHOP_CONTINUE", "Continue shopping");
define("WEBSHOP_MOREDETAILS", "More details");
define("WEBSHOP_NEXT_PAGE", "Next page --&gt;");
define("WEBSHOP_PREV_PAGE", "&lt;-- Previous page");
define("WEBSHOP_ORDER_DETAILS", "Order Details");
define("WEBSHOP_ORDER_NUMBER", "Order Number");
define("WEBSHOP_ORDERNOW", "Order Now");
define("WEBSHOP_COMPLETE_ORDER", "Please fill out the following information below to complete your order.");
define("WEBSHOP_THANKYOU", "Thank you for your order! We will process it as soon as possible.");
define("WEBSHOP_EMAIL_SUBJECT", "Order Confirmation");
define("WEBSHOP_SPECIAL_INSTRUCTIONS", "Comments/Special Instructions:");
define("WEBSHOP_NAME", "Name");
define("WEBSHOP_ADDRESS", "Address");
define("WEBSHOP_CITY", "City");
define("WEBSHOP_STATE", "State");
define("WEBSHOP_ZIP", "Zip");
define("WEBSHOP_PHONE", "Phone");
define("WEBSHOP_FAX", "Fax");
define("WEBSHOP_EMAIL", "Email");
define("WEBSHOP_INVALID_INPUT", "We're sorry, but you must provide the following field(s) before continuing:");

function webshop_verify_order($order_number)
{
   global $db;
   if (strlen($order_number) <> 25) 
   {
      return false;
   }
   $sql = "SELECT order_number FROM CMS_WEBSHOP_ORDERS WHERE order_number = '$order_number'";
   $result = mysql_query($sql, $db);
   if (mysql_num_rows($result) == 1)
   {
      return true;
   } 
   return false;
}

function webshop_verify_product($product_id)
{
   global $db;
   $sql = "SELECT id FROM CMS_WEBSHOP_PRODUCTS WHERE id = '$product_id'";
   $result = mysql_query($sql, $db);
   if (mysql_num_rows($result) == 1)
   {
      return true;
   } 
   return false;
}

function webshop_after_content($id)
{
   global $cms_content, $db;

   $sql = "SELECT * FROM CMS_WEBSHOP WHERE page_id = '$id'";
   $result = mysql_query($sql, $db);
   $data = mysql_fetch_array($result);
   if (!$data)
      return;

   $webshop_enabled = $data['webshop_enabled'];
   if ($webshop_enabled == 0)
      return;

   $order_number = isset($_SESSION['order_number']) ? $_SESSION['order_number'] : '';
   $action = isset($_REQUEST['action']) ? $_REQUEST['action'] : '';
   $webshop_currency_sign = $data['webshop_currency_sign'];
   $webshop_include_shipping = $data['webshop_include_shipping'];
   $webshop_payment_processor = $data['webshop_payment_processor'];
   $webshop_payment_processor_account = $data['webshop_payment_processor_account'];
   $webshop_limit = $data['webshop_limit'];
   $webshop_imagewidth = $data['webshop_imagewidth'];
   $imagespath = basename(dirname(dirname(__FILE__)))."/".basename(dirname(__FILE__))."/images";

   $cms_content .= "<p align=\"right\">\n";
   $cms_content .= "<a href=\"";
   $cms_content .= MAIN_SCRIPT;
   $cms_content .= "?page=$id&amp;action=webshop_viewcart\">".WEBSHOP_VIEWCART."</a> | <a href=\"";
   $cms_content .= MAIN_SCRIPT;
   $cms_content .= "?page=$id\">".WEBSHOP_OVERVIEW."</a> | <a href=\"";
   $cms_content .= MAIN_SCRIPT;
   $cms_content .= "?page=$id&amp;action=webshop_search\">".WEBSHOP_SEARCH."</a></p><br>\n";

   if ($action == 'webshop_addtocart')
   {
      $productid = $_REQUEST['productid'];
      if (!webshop_verify_order($order_number))
      {
         $order_number = "";
         for ($i = 1; $i <= 25; $i++) 
         {
            mt_srand((int) (microtime() * 1000000));
            $order_number .= dechex(mt_rand(0, 15));
         }
         $order_number = strtoupper($order_number);
         $sql  = "INSERT INTO CMS_WEBSHOP_ORDERS (`order_number`, `order_date`, `order_status`) VALUES ('$order_number', now(), '0')";
         mysql_query($sql) or die(mysql_error());
         $_SESSION['order_number'] = $order_number;
      }
      if (webshop_verify_product($productid)) 
      {
         $sql = "SELECT item_count FROM CMS_WEBSHOP_ORDERITEMS WHERE order_number = '$order_number' AND product_id = '$productid'";
         $result = mysql_query($sql, $db);

         echo mysql_error();
         if (mysql_num_rows($result) == 0) 
         {
            $sql = "INSERT INTO CMS_WEBSHOP_ORDERITEMS (`order_number`, `product_id`, `item_count`) VALUES ('$order_number', '$productid', '1')";
         } 
         else 
         {
            $data = mysql_fetch_assoc($result);
            $item_count = $data["item_count"] + 1;
            $sql = "UPDATE CMS_WEBSHOP_ORDERITEMS SET item_count='$item_count' WHERE order_number='$order_number' AND product_id = '$productid'";
         }
         mysql_query($sql) or die(mysql_error());
      }
      $action = 'webshop_viewcart';
   }
   else
   if ($action == 'webshop_removefromcart')
   {
      $productid = $_REQUEST['productid'];
      if (webshop_verify_product($productid) && (webshop_verify_order($order_number))) 
      {
          $sql  = "DELETE FROM CMS_WEBSHOP_ORDERITEMS WHERE order_number = '$order_number' AND product_id = '$productid'";
          mysql_query($sql) or die(mysql_error());
      }
      $action = 'webshop_viewcart';
   }
   else
   if ($action == 'webshop_updatecart')
   {
      if (webshop_verify_order($order_number))
      {
         $sql  = "SELECT product_id, item_count FROM CMS_WEBSHOP_ORDERITEMS WHERE order_number = '$order_number'";
         $result = mysql_query($sql, $db);
         while ($data = mysql_fetch_assoc($result)) 
         {
            $product_id = $data['product_id'];
            if (isset($_POST[$product_id])) 
            {
               $new_count = $_POST[$product_id];
               if (is_numeric($new_count)) 
               {
                  if ($new_count != $data['item_count']) 
                  {
                     if ($new_count < 1) 
                     {
                        $sql  = "DELETE FROM CMS_WEBSHOP_ORDERITEMS WHERE order_number = '$order_number' AND product_id = '$product_id'";
                     } 
                     else 
                     {
                        $sql  = "UPDATE CMS_WEBSHOP_ORDERITEMS SET item_count='$new_count' WHERE order_number = '$order_number' AND product_id = '$product_id'";
                     }
                     mysql_query($sql) or die(mysql_error());
                  }
               }
            }
         }
      }
      $action = 'webshop_viewcart';
   }

   if ($action == 'webshop_details')
   {
      $productid = $_REQUEST['productid'];

      $sql  = "SELECT * FROM CMS_WEBSHOP_PRODUCTS WHERE id = '$productid'";
      $result = mysql_query($sql, $db);
      if ($data = mysql_fetch_array($result))
      {
         $cms_content .= "<table border=\"0\" cellpadding=\"10\" cellspacing=\"0\" width=\"100%\">\n";
         $cms_content .= "<tr><td valign=\"top\"><p align=\"center\">";

         $product_image = $imagespath . "/" . $data['product_image'];
         if ($data['product_image'] == '' || !file_exists($product_image)) 
         {
            $product_image = $imagespath . "/nopreview.png";
         }
         $webshop_imageheight = $webshop_imagewidth;
         if (file_exists($product_image))
         {
            list ($width, $height) = getimagesize($product_image);
            $webshop_imageheight = $height / ($width / $webshop_imagewidth);
         }
         $cms_content .= "<img alt=\"" . htmlspecialchars($data['product_name']) . "\" style=\"border-width:0px;width:".$webshop_imagewidth."px;height:".$webshop_imageheight."px\" src=\"" . $product_image . "\"><br>\n";
         $cms_content .= "<strong>".$webshop_currency_sign."&nbsp;";
         $cms_content .= number_format($data['product_price'], 2);
         $cms_content .= "</strong><br>";
         $cms_content .= "</p></td>";
         $cms_content .= "<td>";
         $cms_content .= "<h3>" . htmlspecialchars($data['product_name']) . "</h3>";
         $cms_content .= "<p><a href=\"";
         $cms_content .= MAIN_SCRIPT;
         $cms_content .= "?page=$id&amp;action=webshop_addtocart&amp;productid=";
         $cms_content .=  $data['id'];
         $cms_content .= "\" title=\"".WEBSHOP_ADDTOCART."\">";
         $cms_content .= "<img align=\"texttop\" alt=\"".WEBSHOP_ADDTOCART."\" border=\"0\" src=\"./";
         $cms_content .= basename(dirname(dirname(__FILE__)));
         $cms_content.= "/";
         $cms_content.= basename(dirname(__FILE__));
         $cms_content.= "/images/addtocart.gif\">&nbsp;";
         $cms_content.= WEBSHOP_ADDTOCART;
         $cms_content .= "</a></p><br>";
         $cms_content .= "<p><strong>" . htmlspecialchars($data['product_description']) . "</strong></p>";
         $cms_content .= htmlspecialchars($data['product_details']);
         $cms_content .= "</td></tr>\n";
         $cms_content .= "</table>\n";
      }
      return;
   }
   else
   if ($action == 'webshop_viewcart')
   {
      $totalcount = 0;
      $totalamount = 0;
      $totalshipping = 0;
      $cart = "";
      $sql  = "SELECT CMS_WEBSHOP_ORDERITEMS.product_id, CMS_WEBSHOP_ORDERITEMS.item_count, CMS_WEBSHOP_PRODUCTS.product_name, CMS_WEBSHOP_PRODUCTS.product_price, CMS_WEBSHOP_PRODUCTS.product_shipping FROM CMS_WEBSHOP_PRODUCTS RIGHT JOIN CMS_WEBSHOP_ORDERITEMS ON CMS_WEBSHOP_PRODUCTS.id = CMS_WEBSHOP_ORDERITEMS.product_id WHERE order_number= '$order_number' ORDER BY CMS_WEBSHOP_PRODUCTS.product_name ASC";
      $result = mysql_query($sql, $db);
      while ($data = mysql_fetch_assoc($result)) 
      {
         $cart .= "<tr>";
         $cart .= "<td><a href=\"";
         $cart .= MAIN_SCRIPT;
         $cart .= "?page=$id&amp;action=webshop_details&amp;productid=";
         $cart .=  $data['product_id'];
         $cart .=  "\">" . htmlspecialchars($data['product_name']) . "</a></td>";
         $cart .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($data['product_price'], 2) . "</td>";
         $cart .= "<td style=\"text-align: right\"><input class=\"cms_input\" name=\"" . $data['product_id'] . "\" type=\"text\" size=\"4\" style=\"text-align: right\" value=\"" . $data['item_count'] . "\"></td>";
         $subtotal = $data['product_price'] * $data['item_count'];
         $cart .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($subtotal, 2) . "</td>";
         $cart .= "<td style=\"text-align: right\"><a href=\"";
         $cart .= MAIN_SCRIPT;
         $cart .= "?page=$id&amp;action=webshop_removefromcart&amp;productid=";
         $cart .=  $data['product_id'];
         $cart .=  "\"><img alt=\"Remove\" border=\"0\" style=\"width:16px;height:16px\" src=\"./";
         $cart .= basename(dirname(dirname(__FILE__)));
         $cart .= "/";
         $cart .= basename(dirname(__FILE__));
         $cart .= "/images/remove.gif\"></a></td>";

         $cart .= "</tr>\n";
         $totalcount = $totalcount + $data['item_count'];
         $totalamount = $totalamount + $subtotal;
         $totalshipping = $totalshipping + $data['product_shipping']*$data['item_count'];
      }
      $cms_content .= "<form action=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "\" method=\"post\">\n";
      $cms_content .= "<input type=\"hidden\" name=\"page\" value=\"$id\">\n";
      $cms_content .= "<input type=\"hidden\" name=\"action\" value=\"webshop_updatecart\">\n";
      $cms_content .= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" width=\"100%\">\n";
      $cms_content .= "<tr style=\"background-color: #ECE9D8\"><th style=\"text-align: left\">".WEBSHOP_PRODUCTNAME."</th><th>".WEBSHOP_PRICE."</th><th style=\"text-align: right\">".WEBSHOP_QUANTITY."</th><th>".WEBSHOP_AMOUNT."</th><th>&nbsp;</th></tr>\n";
      $cms_content .= $cart;

      if ($webshop_include_shipping)
      {
         $cms_content .= "<tr style=\"background-color: #ECE9D8\">\n";
         $cms_content .= "<th style=\"text-align: left\">".WEBSHOP_SHIPPING.":</th>\n";
         $cms_content .= "<th>&nbsp;</th>\n";
         $cms_content .= "<th>&nbsp;</th>\n";
         $cms_content .= "<th style=\"text-align: right\">";
         $cms_content .= $webshop_currency_sign;
         $cms_content .= number_format($totalshipping, 2);
         $cms_content .= "</th>\n";
         $cms_content .= "<th>&nbsp;</th>\n";
         $cms_content .= "</tr>\n";
         $totalamount += $totalshipping;
      }

      $cms_content .= "<tr style=\"background-color: #ECE9D8\">\n";
      $cms_content .= "<th style=\"text-align: left\">".WEBSHOP_TOTAL.":</th>\n";
      $cms_content .= "<th>&nbsp;</th>\n";
      $cms_content .= "<th style=\"text-align: right\" style=\"border-top: solid 1px black; border-bottom: double 3px black\">";
      $cms_content .= number_format($totalcount, 0);
      $cms_content .= "</th>\n";
      $cms_content .= "<th style=\"border-top: solid 1px black; border-bottom: double 3px black; text-align: right\">\n";
      $cms_content .= $webshop_currency_sign;
      $cms_content .= number_format($totalamount, 2);
      $cms_content .= "</th>\n";
      $cms_content .= "<th>&nbsp;</th>\n";
      $cms_content .= "</tr>\n";
      $cms_content .= "<tr>\n";
      $cms_content .= "<td colspan=\"5\" style=\"padding-top: 10px; text-align: right\">\n";
      $cms_content .= "<input class=\"cms_button\" name=\"submit\" type=\"submit\" value=\"".WEBSHOP_UPDATE."\">\n";
      $cms_content .= "<input class=\"cms_button\" onclick=\"document.location='";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id'\"type=\"button\" value=\"".WEBSHOP_CONTINUE."\">\n";
      $cms_content .= "<input class=\"cms_button\" onclick=\"document.location='";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id&amp;action=webshop_checkout'\" type=\"button\" value=\"".WEBSHOP_CHECKOUT."\">\n";
      $cms_content .= "</td>\n";
      $cms_content .= "</tr>\n";
      $cms_content .= "</table>\n";
      $cms_content .= "</form>\n";
      return;
   }
   else
   if ($action == 'webshop_checkout')
   {
      if (webshop_verify_order($order_number)) 
      {
         if ($webshop_payment_processor == '' || $webshop_payment_processor == 'default')
         {
            $cms_content .= "<script type=\"text/javascript\">\n";
            $cms_content .= "function validateForm(theform)\n";
            $cms_content .= "{\n";
            $cms_content .= "   var bInvalidInput = false;\n";
            $cms_content .= "   var strFields = \"\";\n";
            $cms_content .= "   if (theform.customer_name.value == '')\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_NAME."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   if (theform.customer_address.value == '')\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_ADDRESS."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   if (theform.customer_city.value == '')\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_CITY."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   if (theform.customer_state.value == '')\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_STATE."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   if (theform.customer_zip.value == '')\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_ZIP."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   var regexp = /^([0-9a-z]([-.\\w]*[0-9a-z])*@(([0-9a-z])+([-\\w]*[0-9a-z])*\\.)+[a-z]{2,6})$/i;\n";
            $cms_content .= "   if (theform.customer_email.value == '' || !regexp.test(theform.customer_email.value))\n";
            $cms_content .= "   {\n";
            $cms_content .= "      bInvalidInput = true;\n";
            $cms_content .= "      strFields += \"     ".WEBSHOP_EMAIL."\\n\";\n";
            $cms_content .= "   }\n";
            $cms_content .= "   if (bInvalidInput)\n";
            $cms_content .= "   {\n";
            $cms_content .= "      alert(\"".WEBSHOP_INVALID_INPUT."\\n\" + strFields);\n";
            $cms_content .= "      return false;\n";
            $cms_content .= "   }\n";
            $cms_content .= "   return true;\n";
            $cms_content .= "}\n";
            $cms_content .= "</script>\n";
          }
          $cms_content .= "<h3>".WEBSHOP_ORDER_DETAILS."</h3>\n";
          $cms_content .= "<p>".WEBSHOP_ORDER_NUMBER.": ".$order_number."</p><br>\n";

          if ($webshop_payment_processor == 'paypal')
          {
             $cms_content .= "<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\">\n";
          }
          else
          if ($webshop_payment_processor == 'authorize.net')
          {
             $cms_content .= "<form action=\"https://secure.authorize.net/gateway/transact.dll\" method=\"post\">\n";
          }
          else
          if ($webshop_payment_processor == 'worldpay')
          {
             $cms_content .= "<form action=\"https://select.worldpay.com/wcc/purchase\" method=\"post\">\n";
          }
          else
          if ($webshop_payment_processor == 'linkpoint')
          {
             $cms_content .= "<form action=\"https://secure.linkpt.net/lpcentral/servlet/lppay\" method=\"post\">\n";
          }
          else
          {
             $cms_content .= "<form action=\"";
             $cms_content .= MAIN_SCRIPT;
             $cms_content .= "?page=$id&amp;action=webshop_order\" method=\"post\" onsubmit=\"return validateForm(this)\">\n";
          }

          $cms_content .= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" width=\"100%\">\n";
          $cms_content .= "<tr bgcolor=\"#CCCCCC\"><th style=\"text-align: left\">".WEBSHOP_PRODUCTNAME."</th><th style=\"text-align: right\">".WEBSHOP_PRICE."</th><th style=\"text-align: right\">".WEBSHOP_QUANTITY."</th><th style=\"text-align: right\">".WEBSHOP_AMOUNT."</th></tr>\n";

          $totalcount = 0;
          $totalamount = 0;
          $totalshipping = 0;
          $index = 1;
          $payment_processor_description = '';

          $sql  = "SELECT CMS_WEBSHOP_ORDERITEMS.product_id, CMS_WEBSHOP_ORDERITEMS.item_count, CMS_WEBSHOP_PRODUCTS.product_name, CMS_WEBSHOP_PRODUCTS.product_sku, CMS_WEBSHOP_PRODUCTS.product_price, CMS_WEBSHOP_PRODUCTS.product_shipping ";
          $sql .= "FROM `CMS_WEBSHOP_PRODUCTS` RIGHT JOIN `CMS_WEBSHOP_ORDERITEMS` ON CMS_WEBSHOP_PRODUCTS.id = CMS_WEBSHOP_ORDERITEMS.product_id ";
          $sql .= "WHERE `order_number`= '$order_number' ";
          $sql .= "ORDER BY CMS_WEBSHOP_PRODUCTS.product_name ASC ";
          $sql .= ";";
 
          $result = mysql_query($sql) or die(mysql_error());
          while ($data = mysql_fetch_assoc($result)) 
          {
             $cms_content .= "<tr bgcolor=\"#EEEEEE\">\n";            
             $cms_content .= "<td>" . htmlspecialchars($data['product_name']) . " (" . $data['product_sku'] . ")</td>\n";
             $cms_content .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($data['product_price'], 2) . "</td>\n";
             $cms_content .= "<td style=\"text-align: right\">" . number_format($data['item_count'], 0) . "</td>\n";
             $subtotal = $data['product_price'] * $data['item_count'];
             $cms_content .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($subtotal, 2) . "</td>\n";
             $cms_content .= "</tr>\n";
             $totalcount = $totalcount + $data['item_count'];
             $totalamount = $totalamount + $subtotal;
             if ($webshop_include_shipping)
             {
                $totalshipping = $totalshipping + $data['product_shipping']*$data['item_count'];
             }

             if ($webshop_payment_processor == 'paypal')
             {
                $cms_content .= "<input type=\"hidden\" name=\"item_number_". $index . "\" value=\"" . $data['product_sku'] . "\">\n"; 
                $cms_content .= "<input type=\"hidden\" name=\"quantity_" . $index . "\" value=\"" . $data['item_count'] . "\">\n"; 
                $cms_content .= "<input type=\"hidden\" name=\"amount_" . $index . "\" value=\"" . $data['product_price'] . "\">\n"; 
                $cms_content .= "<input type=\"hidden\" name=\"item_name_" . $index . "\" value=\"" . htmlspecialchars($data['product_name']) . "\">\n"; 
                $cms_content .= "<input type=\"hidden\" name=\"shipping_" . $index . "\" value=\"" . $totalshipping . "\">";
//              $cms_content .= "<input type=\"hidden\" name=\"on0_" . $index . "\" value=\"" . $data['order_option0'] . "\">";
             }
             else
             {
                $payment_processor_description .= "[";
                $payment_processor_description .= $data['item_count'];
                $payment_processor_description .= "], ";
                $payment_processor_description .= $data['product_price'];
                $payment_processor_description .= ", ";
                $payment_processor_description .= $data['product_sku'];
                $payment_processor_description .= ", ";
                $payment_processor_description .= $data['product_name'];
                $payment_processor_description .= "\n";
             }
             $index++;
          }

          if ($webshop_include_shipping)
          {
             $cms_content .= "<tr style=\"background-color: #CCCCCC\">\n";
             $cms_content .= "<th style=\"text-align: left\">".WEBSHOP_SHIPPING.":</th>\n";
             $cms_content .= "<th>&nbsp;</th>\n";
             $cms_content .= "<th>&nbsp;</th>\n";
             $cms_content .= "<th style=\"text-align: right\">";
             $cms_content .= $webshop_currency_sign;
             $cms_content .= number_format($totalshipping, 2);
             $cms_content .= "</th>\n";
             $cms_content .= "</tr>\n";
             $totalamount += $totalshipping;
          }
        
          $cms_content .= "<tr style=\"background-color: #CCCCCC\">\n";
          $cms_content .= "<th style=\"text-align: left\" colspan=\"2\">".WEBSHOP_TOTAL.":</th>\n";
          $cms_content .= "<th style=\"border-top: solid 1px black; border-bottom: double 3px black; text-align: right\">" . number_format($totalcount, 0) . "</th>\n";
          $cms_content .= "<th style=\"border-top: solid 1px black; border-bottom: double 3px black; text-align: right\">" . $webshop_currency_sign . number_format($totalamount, 2) . "</th>\n";
          $cms_content .= "</tr>\n";
          if ($webshop_payment_processor != '' && $webshop_payment_processor != 'default')
          {
             $cms_content .= "<tr><td colspan=\"4\" style=\"text-align: right\"><input class=\"cms_button\" name=\"submit\" type=\"submit\" value=\"".WEBSHOP_ORDERNOW."\"></td></tr>\n";
          }
          $cms_content .= "</table>\n";

          if ($webshop_payment_processor == 'paypal')
          {
             $cms_content .= "<input type=\"hidden\" name=\"cmd\" value=\"_cart\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"upload\" value=\"1\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"business\" value=\"".$webshop_payment_processor_account."\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"currency_code\" value=\"USD\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"return\" value=\"http://www.yourdomain.com/thankyou.html\">\n";
          }
          else
          if ($webshop_payment_processor == 'authorize.net')
          {
             $cms_content .= "<input type=\"hidden\" name=\"x_Login\" value=\"".$webshop_payment_processor_account."\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"x_Version\" value=\"3.0\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"x_Show_Form\" value=\"PAYMENT_FORM\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"x_Description\" value=\"". $payment_processor_description . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"x_Amount\" value=\"". number_format($totalamount, 2) . "\">\n";
          }
          else
          if ($webshop_payment_processor == 'worldpay')
          {
             $cms_content .= "<input type=\"hidden\" name=\"instId\" value=\"".$webshop_payment_processor_account."\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"currency\" value=\"USD\">\n"; 
             $cms_content .= "<input type=\"hidden\" name=\"testMode\" value=\"0\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"cartId\" value=\"WebPurchase\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"desc\" value=\"". $payment_processor_description . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"amount\" value=\"". number_format($totalamount, 2) . "\">\n";
          }
          else
          if ($webshop_payment_processor == 'linkpoint')
          {
             $cms_content .= "<input type=\"hidden\" name=\"storename\" value=\"".$webshop_payment_processor_account."\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"mode\" value=\"fullpay\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"chargetotal\" value=\"". number_format($totalamount, 2) . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"tax\" value=\"0\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"subtotal\" value=\"". $webshop_currency_sign . number_format($totalamount-$webshop_include_shipping, 2) . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"shipping\" value=\"". $webshop_currency_sign . number_format($totalshipping, 2) . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"desc\" value=\""+ $payment_processor_description + "\">\n";
          } 
          else
          {
             $cms_content .= "<input type=\"hidden\" name=\"order_desc\" value=\"". $payment_processor_description . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"order_subtotal\" value=\"". $webshop_currency_sign . number_format($totalamount-$webshop_include_shipping, 2) . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"order_shipping\" value=\"". $webshop_currency_sign . number_format($totalshipping, 2) . "\">\n";
             $cms_content .= "<input type=\"hidden\" name=\"order_total\" value=\"". $webshop_currency_sign . number_format($totalamount, 2) . "\">\n";

             $cms_content .= "<br>\n";
             $cms_content .= "<p><span><b>".WEBSHOP_COMPLETE_ORDER."</b></span></p>\n";
             $cms_content .= "<table>\n";
             $cms_content .= "<tr><td>".WEBSHOP_NAME.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_name\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_ADDRESS.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_address\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_ADDRESS.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_address2\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_CITY.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_city\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_STATE.": </td><td><input class=\"cms_input\" type=\"text\" size=\"6\"  name=\"customer_state\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_ZIP.": </td><td><input class=\"cms_input\" type=\"text\" size=\"6\"  name=\"customer_zip\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_PHONE.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_phone\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_FAX.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_fax\"></td></tr>\n";
             $cms_content .= "<tr><td>".WEBSHOP_EMAIL.": </td><td><input class=\"cms_input\" type=\"text\" size=\"50\" name=\"customer_email\"></td></tr>\n";
             $cms_content .= "</table>\n";
             $cms_content .= "<p><span><b>".WEBSHOP_SPECIAL_INSTRUCTIONS."</b></span></p>\n";
             $cms_content .= "<span>\n";
             $cms_content .= "<textarea class=\"cms_textarea\" name=\"customer_comments\" rows=\"6\" cols=\"40\">\n";
             $cms_content .= "</textarea>\n";
             $cms_content .= "</span>\n";
             $cms_content .= "<p><input class=\"cms_button\" name=\"submit\" type=\"submit\" value=\"".WEBSHOP_ORDERNOW."\"></p>\n";
          }
          $cms_content .= "</form>\n";

          $sql = "UPDATE CMS_WEBSHOP_ORDERS SET order_status = '1' WHERE order_number = '$order_number'";
          mysql_query($sql, $db) or die(mysql_error());
          return;
      }
   }
   else
   if ($action == 'webshop_order')
   {
      if (webshop_verify_order($order_number)) 
      {
         $customer_name = isset($_POST['customer_name']) ? $_POST['customer_name'] : '';
         $customer_address = isset($_POST['customer_address']) ? $_POST['customer_address'] : '';
         $customer_address2 = isset($_POST['customer_address2']) ? $_POST['customer_address2'] : '';
         $customer_city = isset($_POST['customer_city']) ? $_POST['customer_city'] : '';
         $customer_state = isset($_POST['customer_state']) ? $_POST['customer_state'] : '';
         $customer_zip = isset($_POST['customer_zip']) ? $_POST['customer_zip'] : '';
         $customer_phone = isset($_POST['customer_phone']) ? $_POST['customer_phone'] : '';
         $customer_fax = isset($_POST['customer_fax']) ? $_POST['customer_fax'] : '';
         $customer_email = isset($_POST['customer_email']) ? $_POST['customer_email'] : '';
         $customer_comments = isset($_POST['customer_comments']) ? $_POST['customer_comments'] : '';
         $order_subtotal = isset($_POST['order_subtotal']) ? $_POST['order_subtotal'] : '';
         $order_total = isset($_POST['order_total']) ? $_POST['order_total'] : '';
         $order_shipping = isset($_POST['order_shipping']) ? $_POST['order_shipping'] : '';
         $order_desc = isset($_POST['order_desc']) ? $_POST['order_desc'] : '';

         if (($customer_name == '') || ($customer_address == '') || ($customer_city == '') || ($customer_state == '') || ($customer_zip == '') || ($customer_email == ''))
         {
            $cms_content .= "Invalid user input!<br>\n";
            return;
         }
         if (!preg_match('/^([0-9a-z]([-.\w]*[0-9a-z])*@(([0-9a-z])+([-\w]*[0-9a-z])*\.)+[a-z]{2,6})$/i', $customer_email))
         {
            $cms_content .= "Invalid email address!<br>\n";
            return;
         }
         $today = date("l, F jS Y");
         $message = "";
         $message .= "A new order has been received.  A summary of this order appears below.\n";
         $message .= "\n";
         $message .= "Order Date: $today \n";
         $message .= " \n";
         $message .= "Bill To: \n";
         $message .= "-------- \n";
         $message .= "   $customer_name \n";
         $message .= "   $customer_address \n";
         $message .= "   $customer_address2 \n";
         $message .= "   $customer_city, $customer_state  $customer_zip \n";
         $message .= "   $customer_phone \n";
         $message .= "   $customer_fax \n";
         $message .= "   $customer_email \n";
         $message .= " \n";
         $message .= " \n";

         $message .= "Qty, Price(\$), Product ID, Product Name\n";
         $message .= "===================================================================== \n";
         $message .= $order_desc;
         $message .= "===================================================================== \n";
         $message .= "SUBTOTAL: $order_subtotal \n";
         $message .= "TOTAL: $order_total \n";
         $message .= "\n";
         $message .= "FREIGHT: $order_shipping \n";
         $message .= "\n\n";
         $message .= "Comments: \n";
         $message .= "--------- \n";
         $message .= "$customer_comments \n";
         $message .= " \n";

         $header  = "From: $customer_email\r\n";
         $header .= "Reply-To: $customer_email\r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "X-Mailer: PHP Mail generated by: CMS Shopping Cart\r\n";
         mail($webshop_payment_processor_account, 'New Online Order - '.$order_number, $message, $header);

         $header  = "From: $webshop_payment_processor_account\r\n";
         $header .= "Reply-To: $webshop_payment_processor_account\r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "X-Mailer: PHP Mail generated by: CMS Shopping Cart\r\n";
         mail($customer_email, WEBSHOP_EMAIL_SUBJECT.' - '.$order_number, $message, $header);

         if (get_magic_quotes_gpc())
         {
            $customer_name = stripslashes($customer_name);
            $customer_address = stripslashes($customer_address);
            $customer_address2 = stripslashes($customer_address2);
            $customer_city = stripslashes($customer_city);
            $customer_state = stripslashes($customer_state);
            $customer_zip = stripslashes($customer_zip);
            $customer_phone = stripslashes($customer_phone);
            $customer_fax = stripslashes($customer_fax);
            $customer_email = stripslashes($customer_email);
            $customer_comments = stripslashes($customer_comments);
         }
         $customer_name = mysql_real_escape_string($customer_name);
         $customer_address = mysql_real_escape_string($customer_address);
         $customer_address2 = mysql_real_escape_string($customer_address2);
         $customer_city = mysql_real_escape_string($customer_city);
         $customer_state = mysql_real_escape_string($customer_state);
         $customer_zip = mysql_real_escape_string($customer_zip);
         $customer_phone = mysql_real_escape_string($customer_phone);
         $customer_fax = mysql_real_escape_string($customer_fax);
         $customer_email = mysql_real_escape_string($customer_email);
         $customer_comments = mysql_real_escape_string($customer_comments);

         $sql = "UPDATE CMS_WEBSHOP_ORDERS SET customer_name='$customer_name', customer_address='$customer_address', customer_address2='$customer_address2', customer_city='$customer_city', customer_state='$customer_state', customer_zip='$customer_zip', customer_phone='$customer_phone', customer_fax='$customer_fax', customer_email='$customer_email', customer_comments='$customer_comments' WHERE order_number='$order_number'";
         mysql_query($sql, $db) or die(mysql_error());

         unset($_SESSION['order_number']);

         $cms_content .= "<p>".WEBSHOP_THANKYOU."<br>";
         $cms_content .= "<a href=\"";
         $cms_content .= MAIN_SCRIPT;
         $cms_content .= "?page=$id\">".WEBSHOP_CONTINUE."</a></p><br>\n";
         return;
      }
   }
   if ($action == 'webshop_search')
   {
      $cms_content .= "<h3>".WEBSHOP_SEARCH."</h3>\n";
      $cms_content .= "<form action=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "\" method=\"get\">\n";
      $cms_content .= "<input name=\"page\" type=\"hidden\" value=\"".$id."\">";
      $cms_content .= "<input name=\"action\" type=\"hidden\" value=\"webshop_query\">";
      $cms_content .= "<table border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\n";
      $cms_content .= "<tr><td align=\"right\"><input class=\"cms_input\" name=\"q\" size=\"50\" value=\"\"></td><td align=\"left\">";
      $cms_content .= "<input class=\"cms_button\" style=\"width: 75px; height: 23px;\" type=\"submit\" value=\"".WEBSHOP_SEARCH."\"></td></tr>\n";
      $cms_content .= "</table>\n";
      $cms_content .= "</form>\n";
      return;
   }
   else
   if ($action == 'webshop_query')
   {
      $keyword = $_REQUEST['q'];
      $keyword = strip_tags($keyword);
      $keyword = trim($keyword);
      if (strlen($keyword) > 1) 
      {
         $sql  = "SELECT * FROM CMS_WEBSHOP_PRODUCTS WHERE product_name LIKE '%$keyword%' OR product_description LIKE '%$keyword%' OR product_details LIKE '%$keyword%' ORDER BY product_price DESC";
         $result = mysql_query($sql, $db);
         if (mysql_num_rows($result) < 1) 
         {
            $cms_content .= "<p>".WEBSHOP_SEARCH_NORESULTS."'" . $keyword . "'.</p>";
         } 
         else 
         {
            $cms_content .= "<p>";
            $cms_content .= WEBSHOP_SEARCH_FOUND;
            $cms_content .= mysql_num_rows($result);
            $cms_content .= WEBSHOP_SEARCH_RESULTS;
            $cms_content .= "'" . $keyword . "':</p>\n";
            $cms_content .= "<ol>";
            while ($data = mysql_fetch_array($result))
            {
                $cms_content .= "<li><strong><a href=\"";
                $cms_content .= MAIN_SCRIPT;
                $cms_content .= "?page=$id&amp;action=webshop_details&amp;productid=";
                $cms_content .= $data["id"];
                $cms_content .= "\">";
                $cms_content .= htmlspecialchars($data["product_name"]);
                $cms_content .= "</a></strong><br>";
                $cms_content .= htmlspecialchars($data["product_description"]);
                $cms_content .= "</li>\n";
            } 
            $cms_content .= "</ol>\n";
         } 
      }
      return;
   }

   $offset = 0;
   if (isset($_REQUEST['offset']))
   {
      $offset = (int) $_REQUEST['offset'];
   }
   $cms_content .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"10\" width=\"100%\">\n";

   $sql = "SELECT * FROM CMS_WEBSHOP_PRODUCTS WHERE page_id='$id' ORDER BY product_name ASC LIMIT $offset, $webshop_limit";
   $result = mysql_query($sql, $db);
   while ($data = mysql_fetch_array($result))
   {
      $cms_content .= "<tr><td valign=\"top\">\n";

      $product_image = $imagespath . "/" . $data['product_image'];
      if ($data['product_image'] == '' || !file_exists($product_image)) 
      {
         $product_image = $imagespath . "/nopreview.png";
      } 
      $webshop_imageheight = $webshop_imagewidth;
      if (file_exists($product_image))
      {
         list ($width, $height) = getimagesize($product_image);
         $webshop_imageheight = $height / ($width / $webshop_imagewidth);
      }
      $cms_content .= "<a href=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id&amp;action=webshop_details&amp;productid=";
      $cms_content .= $data['id'];
      $cms_content .= "\"><img alt=\"" . htmlspecialchars($data['product_name']) . "\" style=\"border-width:0px;width:".$webshop_imagewidth."px;height:".$webshop_imageheight."px\" src=\"" . $product_image . "\"></a>";

      $cms_content .= "</td>";
      $cms_content .= "<td valign=\"top\"><p>";
      $cms_content .= "<a href=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id&amp;action=webshop_details&amp;productid=";
      $cms_content .= $data['id'];
      $cms_content .= "\" title=\"" . htmlspecialchars($data['product_name']) ."\">";
      $cms_content .= "<strong style=\"text-transform: uppercase\">" . htmlspecialchars($data['product_name']) . "</strong>";
      $cms_content .= "</a><br>";
      $cms_content .= $data['product_description'];
      $cms_content .= "</p>";
      $cms_content .= "<p>".WEBSHOP_PRICE.":&nbsp;".$webshop_currency_sign."&nbsp;" . $data['product_price'];
      $cms_content .= "<br>".WEBSHOP_SKU.":&nbsp;" . $data['product_sku'];
      $cms_content .= "<br><a href=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id&amp;action=webshop_details&amp;productid=";
      $cms_content .= $data['id'];
      $cms_content .= "\" title=\"" . htmlspecialchars($data['product_name']) ."\">".WEBSHOP_MOREDETAILS."</a>";
      $cms_content .= " | <a href=\"";
      $cms_content .= MAIN_SCRIPT;
      $cms_content .= "?page=$id&amp;action=webshop_addtocart&amp;productid=";
      $cms_content .= $data['id'];
      $cms_content .= "\" title=\"".WEBSHOP_ADDTOCART."\">".WEBSHOP_ADDTOCART."</a>";
      $cms_content .= "</p></td></tr>\n";
   }
   $cms_content .= "</table>\n";

   $this_page = MAIN_SCRIPT;
   $record_count = 0;
   $prev_page = $offset - $webshop_limit;
   $next_page = $offset + $webshop_limit;
    	
   $sql = "SELECT COUNT(*) FROM CMS_WEBSHOP_PRODUCTS WHERE page_id='$id'";
   $result = mysql_query($sql, $db);
   list($record_count) = mysql_fetch_array($result);
   $cms_content .= "<div class=\"navigation\">";
   if ($offset > 0)
   {
      $cms_content .= "<a href=\"$this_page?page=$id&amp;offset=$prev_page\">".WEBSHOP_PREV_PAGE."</a> &nbsp;  &nbsp;";
   }
   if ($next_page < $record_count)
   {
      $cms_content .= "<a href=\"$this_page?page=$id&amp;offset=$next_page\">".WEBSHOP_NEXT_PAGE."</a> &nbsp;  &nbsp;";
   }
   $cms_content .= "</div>";
}

function webshop_tab()
{
   global $id, $db, $plugin;

   $webshop_id = isset($_REQUEST['webshopid']) ? $_REQUEST['webshopid'] : -1;
   $webshop_action = isset($_REQUEST['webshop-action']) ? $_REQUEST['webshop-action'] : '';
   $anchor = "#tab-Webshop";
   $plugin_dir = basename(dirname(__FILE__));
 
   $webshop_enabled = 0;
   $webshop_title = 'webshop';
   $webshop_email = '';
   $webshop_currency_sign = '$';
   $webshop_include_shipping = 0;
   $webshop_payment_processor = 'paypal';
   $webshop_payment_processor_account = 'paypal@youremail.com';
   $webshop_limit = 10;
   $webshop_imagewidth = 100;

   $sql = "SELECT * FROM CMS_WEBSHOP WHERE page_id='$id'";
   $result = mysql_query($sql, $db);
   if ($data = mysql_fetch_array($result))
   {
      $webshop_enabled = $data['webshop_enabled'];
      $webshop_title = $data['webshop_title'];
      $webshop_email = $data['webshop_email'];
      $webshop_currency_sign = $data['webshop_currency_sign'];
      $webshop_include_shipping = $data['webshop_include_shipping'];
      $webshop_payment_processor = $data['webshop_payment_processor'];
      $webshop_payment_processor_account = $data['webshop_payment_processor_account'];
      $webshop_limit = $data['webshop_limit'];
      $webshop_imagewidth = $data['webshop_imagewidth'];
   }

   $html = '';

   if ($webshop_action == 'edit' || $webshop_action == 'new')
   {
      $product_sku = '';
      $product_name = '';
      $product_price = 0;
      $product_shipping = 0;
      $product_description  = '';
      $product_details  = '';
      $product_image  = '';
      $product_count = 0;

      if ($webshop_id >= 0)
      {
         $sql = "SELECT * FROM CMS_WEBSHOP_PRODUCTS WHERE id = '$webshop_id'";
         $result = mysql_query($sql, $db);
         if ($data = mysql_fetch_array($result))
         {
            $product_sku = htmlspecialchars($data['product_sku']);
            $product_name = htmlspecialchars($data['product_name']);
            $product_price = $data['product_price'];
            $product_shipping = $data['product_shipping'];
            $product_description = htmlspecialchars($data['product_description']);
            $product_details = htmlspecialchars($data['product_details']);
//            $product_image = $data['product_image'];
//            $product_count = $data['product_count'];
         }
      }

      $html .= "<script type=\"text/javascript\">\n";
      $html .= "$(document).ready(function()\n";
      $html .= "{\n";
      $html .= "   $('input[name=webshop-save]').click(function(e)\n";
      $html .= "   {\n";
      $html .= "      var form = jQuery(this).closest('form');\n";
      $html .= "      e.preventDefault();\n";
      $html .= "      jQuery.post('./";
      $html .= MAIN_SCRIPT;
      $html .= "?plugin=";
      $html .= $plugin_dir;
      $html .= "', { action: \"webshop-save\", webshopid: \"$webshop_id\", pageid: \"$id\", product_sku: $('input[name=product-sku]').val(), product_name: $('input[name=product-name]').val(), product_price: $('input[name=product-price]').val(), product_shipping: $('input[name=product-shipping]').val(), product_description: $('textarea[name=product-description]').val(), product_details: $('textarea[name=product-details]').val() }, function(result)\n";
      $html .= "      {\n";
      $html .= "         var newId = parseInt(result, 10);\n"; 
      $html .= "         if (newId > 0 && $('input[name=product_image]').val() != '')\n";
      $html .= "         {\n";
      $html .= "            var url = form.attr('action');\n";
      $html .= "            var enctype = form.attr('enctype');\n";
      $html .= "            var target = form.attr('target');\n";
      $html .= "            var action = $('input[name=action]').val(); \n";
      $html .= "            form.attr('action', './";
      $html .= MAIN_SCRIPT;
      $html .= "?plugin=";
      $html .= $plugin_dir;
      $html .= "&product_id='+newId);\n";
      $html .= "            $('input[name=action]').val('webshop-upload'); \n";
      $html .= "            form.attr('enctype', 'multipart/form-data');\n";
      $html .= "            form.attr('target', 'upload_iframe');\n";
      $html .= "            form.submit();\n";
      $html .= "            $('input[name=action]').val(action); \n";
      $html .= "            form.attr('target', target);\n";
      $html .= "            form.attr('action', url);\n";
      $html .= "            form.attr('enctype', enctype);\n";
      $html .= "         }\n";
      $html .= "         window.location = '".MAIN_SCRIPT."?action=edit&id=".$id.$anchor."';\n";
      $html .= "      });\n";
      $html .= "   });\n";
      $html .= "});\n";
      $html .= "</script>\n";

      $html .= "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"4\" border=\"0\">\n";
      $html .= "<tr><td>SKU:</td><td><input type=\"text\" name=\"product-sku\" value=\"" .$product_sku. "\" style=\"width:100%\"></td></tr>\n";
      $html .= "<tr><td>Name:</td><td><input type=\"text\" name=\"product-name\" value=\"" .$product_name. "\" style=\"width:100%\"></td></tr>\n";
      $html .= "<tr><td>Price:</td><td><input type=\"text\" name=\"product-price\" value=\"" .$product_price. "\" size=\"10\"></td></tr>\n";
      $html .= "<tr><td style=\"width:10%;white-space:nowrap;\">Shipping costs:&nbsp;&nbsp;</td><td><input type=\"text\" name=\"product-shipping\" value=\"" .$product_shipping. "\" size=\"10\"></td></tr>\n";
      $html .= "<tr><td>Product image:</td><td><input type=\"file\" name=\"product_image\" style=\"width:100%\"></td></tr>\n";
      $html .= "<tr><td>Description:</td><td><textarea style=\"width:100%\" rows=\"10\" name=\"product-description\">".$product_description."</textarea></td></tr>\n";
      $html .= "<tr><td>Details:</td><td><textarea style=\"width:100%\" rows=\"10\" name=\"product-details\">".$product_details."</textarea></td></tr>\n";
      $html .= "<tr>\n";
      $html .= "<td>&nbsp;</td><td align=left>\n";
      $html .= "<input style=\"background-color:transparent;padding-left:0;text-decoration:underline;border-width:0;cursor:pointer;\" type=\"button\" name=\"webshop-save\" value=\"Save Product\">\n";
      $html .= "<input style=\"background-color:transparent;padding-left:0;text-decoration:underline;border-width:0;cursor:pointer;\" type=\"button\" value=\"Back to overview\" onclick=\"window.location='" .MAIN_SCRIPT."?action=edit&id=".$id.$anchor."'\">\n";
      $html .= "</td>\n";
      $html .= "</tr>\n";
      $html .= "</table>\n";
      $html .= "<iframe name=\"upload_iframe\" src=\"\" style=\"display:none;\"></iframe>\n";
   }
   else
   if ($webshop_action == 'orders')
   {
      $html .= "<script type=\"text/javascript\">\n";
      $html .= "function order_delete(order_no)\n";
      $html .= "{\n";
      $html .= "   jQuery.post('./";
      $html .= MAIN_SCRIPT;
      $html .= "?plugin=";
      $html .= $plugin_dir;
      $html .= "', { action: \"order-delete\", order_number: order_no }, function(result)\n";
      $html .= "   {\n";
      $html .= "      window.location.href = '".MAIN_SCRIPT."?action=edit&id=".$id."&webshop-action=orders".$anchor."';\n";
      $html .= "      window.location.reload(true);\n";
      $html .= "   });\n";
      $html .= "}\n";
      $html .= "function order_confirm(order_no)\n";
      $html .= "{\n";
      $html .= "   jQuery.post('./";
      $html .= MAIN_SCRIPT;
      $html .= "?plugin=";
      $html .= $plugin_dir;
      $html .= "', { action: \"order-confirm\", order_number: order_no }, function(result)\n";
      $html .= "   {\n";
      $html .= "      window.location.href = '".MAIN_SCRIPT."?action=edit&id=".$id."&webshop-action=orders".$anchor."';\n";
      $html .= "      window.location.reload(true);\n";
      $html .= "   });\n";
      $html .= "}\n";
      $html .= "</script>\n";

      $html .= "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\">\n<tr><th>Date</th><th>Order Number</th><th>Status</th><th>Action</th></tr>\n";
   
      $sql = "SELECT * FROM CMS_WEBSHOP_ORDERS ORDER BY order_date DESC";
      $result = mysql_query($sql, $db);
      $num_rows = mysql_num_rows($result);
      if ($num_rows == 0)
      {
         $html .= "<tr><td colspan=\"5\">No orders</td></tr>\n";
      }
      else
      {
         while ($data = mysql_fetch_array($result))
         {
            $html .= "<tr><td>";
            $html .= date('Y-m-d H:i:s', strtotime($data['order_date']));
            $html .= "</td><td>";
            $html .= htmlspecialchars($data['order_number']);
            $html .= "</td><td>";
            if ($data['order_status'] == 0)
            {
               $html .= "Not completed";
            }
            else
            if ($data['order_status'] == 1)
            {
               $html .= "Waiting for payment";
            }
            else
            if ($data['order_status'] == 2)
            {
               $html .= "Payment confirmed";
            }
            $html .= "</td><td><a href=\"./".MAIN_SCRIPT."?action=edit&amp;id=".$id."&amp;orderno=".$data['order_number']."&amp;webshop-action=view_order".$anchor;
            $html .= "\">View</a> | <a href=\"javascript:order_confirm('";
            $html .= $data['order_number'];
            $html .= "')\">Confirm Payment</a> | <a href=\"javascript:order_delete('";
            $html .= $data['order_number'];
            $html .= "')\">Delete</a></td></tr>\n";
         }
      }
      $html .= "</table>\n";
      $html .= "<p><a href=\"".MAIN_SCRIPT."?action=edit&id=".$id.$anchor."\">Back to overview</a></p><br>\n";
   }
   else
   if ($webshop_action == 'view_order')
   {
      $order_number = $_REQUEST['orderno'];
      $sql = "SELECT * FROM CMS_WEBSHOP_ORDERS WHERE order_number = '$order_number'";
      $result = mysql_query($sql, $db);
      if ($order = mysql_fetch_assoc($result)) 
      {
         $html .= "<table border=\"0\" cellpadding=\"0\" cellspacing=\"10\" width=\"100%\">\n";
         $html .= "<tr><td style=\"width:10%;white-space:nowrap;\">Order number: </td><td><strong>$order_number</strong></td></tr>\n<tr><td>Order date: </td><td><strong>". date('Y-m-d H:i:s', strtotime($order['order_date']))."</strong></td></tr>\n<tr><td>Order status: </td><td><strong>";
         if ($order['order_status'] == 0)
         {
            $html .= "Not completed";
         }
         else
         if ($order['order_status'] == 1)
         {
            $html .= "Waiting for payment";
         }
         else
         if ($order['order_status'] == 2)
         {
            $html .= "Payment confirmed";
         }
         $html .= "</strong></td></tr>\n";

         if ($order['customer_name'] != '')
         {
            $html .= "<tr><td>Name: </td><td><strong>".$order['customer_name']."</strong></td></tr>\n";
            $html .= "<tr><td>Address: </td><td><strong>".$order['customer_address']."</strong></td></tr>\n";
            $html .= "<tr><td>Address: </td><td><strong>".$order['customer_address2']."</strong></td></tr>\n";
            $html .= "<tr><td>City: </td><td><strong>".$order['customer_city']."</strong></td></tr>\n";
            $html .= "<tr><td>State: </td><td><strong>".$order['customer_state']."</strong></td></tr>\n";
            $html .= "<tr><td>Zip: </td><td><strong>".$order['customer_zip']."</strong></td></tr>\n";
            $html .= "<tr><td>Phone: </td><td><strong>".$order['customer_phone']."</strong></td></tr>\n";
            $html .= "<tr><td>Fax: </td><td><strong>".$order['customer_fax']."</strong></td></tr>\n";
            $html .= "<tr><td>Email: </td><td><strong>".$order['customer_email']."</strong></td></tr>\n";
            $html .= "<tr><td>Comments: </td><td><strong>".$order['customer_comments']."</strong></td></tr>\n";
         }
         $html .= "</table>\n";

         $html .= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"3\" width=\"100%\">\n";
         $html .= "<tr><th>Product Name</th><th style=\"text-align: right\">Price</th><th style=\"text-align: right\">Quantity</th><th style=\"text-align: right\">Amount</th></tr>\n";

         $totalcount = 0;
         $totalamount = 0;
         $totalshipping = 0;

         $sql  = "SELECT CMS_WEBSHOP_ORDERITEMS.product_id, CMS_WEBSHOP_ORDERITEMS.item_count, CMS_WEBSHOP_PRODUCTS.product_name, CMS_WEBSHOP_PRODUCTS.product_sku, CMS_WEBSHOP_PRODUCTS.product_price, CMS_WEBSHOP_PRODUCTS.product_shipping ";
         $sql .= "FROM `CMS_WEBSHOP_PRODUCTS` RIGHT JOIN `CMS_WEBSHOP_ORDERITEMS` ON CMS_WEBSHOP_PRODUCTS.id = CMS_WEBSHOP_ORDERITEMS.product_id ";
         $sql .= "WHERE `order_number`= '$order_number' ";
         $sql .= "ORDER BY CMS_WEBSHOP_PRODUCTS.product_name ASC";
 
         $result = mysql_query($sql) or die(mysql_error());
         while ($data = mysql_fetch_assoc($result)) 
         {
            $html .= "<tr>\n";            
            $html .= "<td>" . htmlspecialchars($data['product_name']) . " (" . $data['product_sku'] . ")</td>\n";
            $html .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($data['product_price'], 2) . "</td>\n";
            $html .= "<td style=\"text-align: right\">" . number_format($data['item_count'], 0) . "</td>\n";
            $subtotal = $data['product_price'] * $data['item_count'];
            $html .= "<td style=\"text-align: right\">" . $webshop_currency_sign . number_format($subtotal, 2) . "</td>\n";
            $html .= "</tr>\n";
            $totalcount = $totalcount + $data['item_count'];
            $totalamount = $totalamount + $subtotal;
            if ($webshop_include_shipping)
            {
               $totalshipping = $totalshipping + $data['product_shipping']*$data['item_count'];
            }
         }
         if ($webshop_include_shipping)
         {
            $html .= "<tr>\n";
            $html .= "<th style=\"text-align: left\">Shipping:</th>\n";
            $html .= "<th>&nbsp;</th>\n";
            $html .= "<th>&nbsp;</th>\n";
            $html .= "<th style=\"text-align: right\">";
            $html .= $webshop_currency_sign;
            $html .= number_format($totalshipping, 2);
            $html .= "</th>\n";
            $html .= "</tr>\n";
            $totalamount += $totalshipping;
         }
         $html .= "<tr>\n";
         $html .= "<th style=\"text-align: left\" colspan=\"2\">Total</th>\n";
         $html .= "<th style=\"text-align: right\">" . number_format($totalcount, 0) . "</th>\n";
         $html .= "<th style=\"text-align: right\">" . $webshop_currency_sign . number_format($totalamount, 2) . "</th>\n";
         $html .= "</tr>\n";
         $html .= "</table>\n";
      }
      else
      {
         $html .= "<p>Invalid order number!</p>\n";
      }
      $html .= "<p><a href=\"".MAIN_SCRIPT."?action=edit&id=".$id."&webshop-action=orders".$anchor."\">Back to overview</a></p>\n";
   }
   else
   {
      $html .= "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\">\n";
      $html .= "<tr><td style=\"width:10%;white-space:nowrap;\">Enable webshop for this page:&nbsp;&nbsp;</td><td><select name=\"webshop-enabled\" size=\"1\"><option value=\"0\"";
      if ($webshop_enabled == 0)
      {
         $html .= " selected";
      }
      $html .= ">disabled</option><option value=\"1\"";
      if ($webshop_enabled == 1)
      {
         $html .= " selected";
      }
      $html .= ">enabled</option></select></td></tr>\n";
      $html .= "<tr><td>Webshop title:</td><td><input name=\"webshop-title\" style=\"width:100%\" value=\"$webshop_title\"></td></tr>\n";
      $html .= "<tr><td>Notification email:</td><td><input name=\"webshop-email\" style=\"width:100%\" value=\"$webshop_email\"></td></tr>\n";
      $html .= "<tr><td>Currency sign:</td><td><input name=\"webshop-currency-sign\" size=\"4\" value=\"$webshop_currency_sign\"></td></tr>\n";
      $html .= "<tr><td>Products per page:</td><td><input name=\"webshop-limit\" size=\"4\" value=\"$webshop_limit\"></td></tr>";
      $html .= "<tr><td>Image width:</td><td><input name=\"webshop-imagewidth\" size=\"4\" value=\"$webshop_imagewidth\"></td></tr>";
      $html .= "<tr><td>Include shipping:</td><td><select name=\"webshop-include-shipping\" size=\"1\"><option value=\"0\"";
      if ($webshop_include_shipping == 0)
      {
         $html .= " selected";
      }
      $html .= ">no</option><option value=\"1\"";
      if ($webshop_include_shipping == 1)
      {
         $html .= " selected";
      }
      $html .= ">yes</option></select></td></tr>\n";

      $html .= "<tr><td>Payment processor:</td><td><select name=\"webshop-payment-processor\" size=\"1\">";

      $html .= "<option value=\"default\"";
      if ($webshop_payment_processor == 'default' || $webshop_payment_processor == '')
      {
         $html .= " selected";
      }
      $html .= ">Default</option>";

      $html .= "<option value=\"paypal\"";
      if ($webshop_payment_processor == 'paypal')
      {
         $html .= " selected";
      }
      $html .= ">PayPal</option>";

      $html .= "<option value=\"authorize.net\"";
      if ($webshop_payment_processor == 'authorize.net')
      {
         $html .= " selected";
      }
      $html .= ">Authorize.net</option>";

      $html .= "<option value=\"worldpay\"";
      if ($webshop_payment_processor == 'worldpay')
      {
         $html .= " selected";
      }
      $html .= ">WorldPay</option>";

      $html .= "<option value=\"linkpoint\"";
      if ($webshop_payment_processor == 'linkpoint')
      {
         $html .= " selected";
      }
      $html .= ">LinkPoint</option>";

      $html .= "</select></td></tr>\n";
      $html .= "<tr><td>Account ID:</td><td><input name=\"webshop-payment-processor-account\" style=\"width:100%\" value=\"$webshop_payment_processor_account\"></td></tr>\n";
      $html .= "</table><br>\n";

      $html .= "<p><a href=\"".MAIN_SCRIPT."?action=edit&id=".$id."&webshop-action=new".$anchor."\">Add Product</a> | <a href=\"".MAIN_SCRIPT."?action=edit&id=".$id."&webshop-action=orders".$anchor."\">View Orders</a></p>\n";

      $html .= "<script type=\"text/javascript\">\n";
      $html .= "function webshop_delete(id)\n";
      $html .= "{\n";
      $html .= "   jQuery.post('./";
      $html .= MAIN_SCRIPT;
      $html .= "?plugin=";
      $html .= $plugin_dir;
      $html .= "', { action: \"webshop-delete\", webshopid: id }, function(result)\n";
      $html .= "   {\n";
      $html .= "      window.location.href = '".MAIN_SCRIPT."?action=edit&id=".$id.$anchor."';\n";
      $html .= "      window.location.reload(true);\n";
      $html .= "   });\n";
      $html .= "}\n";
      $html .= "</script>\n";
      $html .= "<table width=\"100%\" cellspacing=\"0\" cellpadding=\"2\">\n<tr><th>SKU</th><th>Name</th><th>Description</th><th>Price</th><th>Action</th></tr>\n";
   
      $sql = "SELECT * FROM CMS_WEBSHOP_PRODUCTS WHERE page_id='$id' ORDER BY product_name ASC";
      $result = mysql_query($sql, $db);
      $num_rows = mysql_num_rows($result);
      if ($num_rows == 0)
      {
         $html .= "<tr><td>No products yet</td><td>&nbsp;</td><td>&nbsp;</td></tr>\n";
      }
      else
      {
         while ($data = mysql_fetch_array($result))
         {
            $html .= "<tr><td>";
            $html .= htmlspecialchars($data['product_sku']);
            $html .= "</td><td>";
            $html .= htmlspecialchars($data['product_name']);
            $html .= "</td><td>";
            $html .= htmlspecialchars($data['product_description']);
            $html .= "</td><td>";
            $html .= $data['product_price'];
            $html .= "</td><td><a href=\"./".MAIN_SCRIPT."?action=edit&amp;id=".$id."&amp;webshopid=".$data['id']."&amp;webshop-action=edit".$anchor;
            $html .= "\">Edit</a> | <a href=\"javascript:webshop_delete(";
            $html .= $data['id'];
            $html .= ")\">Delete</a></td></tr>\n";
         }
      }
      $html .= "</table>\n";
   }
   return $html;
}

function webshop_init()
{
   global $authorized, $db;
   if ($authorized)
   {
       $sql = "CREATE TABLE IF NOT EXISTS CMS_WEBSHOP (
              id INT UNSIGNED NOT NULL AUTO_INCREMENT,
              page_id INT, 
              webshop_enabled INT, 
              webshop_title TEXT, 
              webshop_email TEXT, 
              webshop_currency_sign TEXT,
              webshop_include_shipping INT, 
              webshop_payment_processor TEXT,
              webshop_payment_processor_account TEXT,
              webshop_limit INT, 
              webshop_imagewidth INT, 
              PRIMARY KEY(id));";
      mysql_query($sql, $db) or die(mysql_error());

      $sql = "CREATE TABLE IF NOT EXISTS CMS_WEBSHOP_PRODUCTS (
              id INT UNSIGNED NOT NULL AUTO_INCREMENT,
              page_id INT, 
              product_sku TEXT,
              product_name TEXT,
              product_price float,
              product_shipping float,
              product_description TEXT,
              product_details TEXT,
              product_image TEXT,
              product_count INT,
              PRIMARY KEY(id));";
      mysql_query($sql, $db) or die(mysql_error());

      $sql = "CREATE TABLE IF NOT EXISTS CMS_WEBSHOP_ORDERS (
              id INT UNSIGNED NOT NULL AUTO_INCREMENT,
              order_number TEXT, 
              order_date TIMESTAMP, 
              order_status INT, 
              customer_name TEXT, 
              customer_address TEXT, 
              customer_address2 TEXT, 
              customer_city TEXT, 
              customer_state TEXT, 
              customer_zip TEXT, 
              customer_phone TEXT, 
              customer_fax TEXT, 
              customer_email TEXT, 
              customer_comments TEXT, 
              PRIMARY KEY(id));";
      mysql_query($sql, $db) or die(mysql_error());

      $sql = "CREATE TABLE IF NOT EXISTS CMS_WEBSHOP_ORDERITEMS (
              id INT UNSIGNED NOT NULL AUTO_INCREMENT,
              order_number TEXT, 
              product_id INT, 
              item_count INT, 
              PRIMARY KEY(id));";
      mysql_query($sql, $db) or die(mysql_error());
   }
}

function webshop_update($id)
{
   global $authorized, $db;
   if ($authorized)
   {
      if (isset($_REQUEST['webshop-enabled']) && 
          isset($_REQUEST['webshop-title']) &&
          isset($_REQUEST['webshop-email']) &&
          isset($_REQUEST['webshop-currency-sign']) &&
          isset($_REQUEST['webshop-include-shipping']) &&
          isset($_REQUEST['webshop-payment-processor']) &&
          isset($_REQUEST['webshop-payment-processor-account']) &&
          isset($_REQUEST['webshop-limit']) &&
          isset($_REQUEST['webshop-imagewidth']))
      {
         $webshop_enabled = intval($_REQUEST['webshop-enabled']);
         $webshop_title = $_REQUEST['webshop-title'];
         $webshop_email = $_REQUEST['webshop-email'];
         $webshop_currency_sign = $_REQUEST['webshop-currency-sign'];
         $webshop_include_shipping = intval($_REQUEST['webshop-include-shipping']);
         $webshop_payment_processor = $_REQUEST['webshop-payment-processor'];
         $webshop_payment_processor_account = $_REQUEST['webshop-payment-processor-account'];
         $webshop_limit = intval($_REQUEST['webshop-limit']);
         $webshop_imagewidth = intval($_REQUEST['webshop-imagewidth']);
         if (get_magic_quotes_gpc())
         {
            $webshop_title = stripslashes($webshop_title);
            $webshop_email = stripslashes($webshop_email);
            $webshop_currency_sign = stripslashes($webshop_currency_sign);
            $webshop_payment_processor = stripslashes($webshop_payment_processor);
            $webshop_payment_processor_account = stripslashes($webshop_payment_processor_account);
         }
         $webshop_title = mysql_real_escape_string($webshop_title);
         $webshop_email = mysql_real_escape_string($webshop_email);
         $webshop_currency_sign = mysql_real_escape_string($webshop_currency_sign);
         $webshop_payment_processor = mysql_real_escape_string($webshop_payment_processor);
         $webshop_payment_processor_account = mysql_real_escape_string($webshop_payment_processor_account);

         $sql = "SELECT * FROM CMS_WEBSHOP WHERE page_id='$id'";
         $result = mysql_query($sql, $db);
         if (mysql_num_rows($result) == 0)
            $sql = "INSERT INTO CMS_WEBSHOP (`webshop_enabled`, `webshop_title`, `webshop_email`, `webshop_currency_sign`, `webshop_include_shipping`, `webshop_payment_processor`, `webshop_payment_processor_account`, `webshop_limit`, `webshop_imagewidth`, `page_id`) VALUES ('$webshop_enabled', '$webshop_title', '$webshop_email', '$webshop_currency_sign', '$webshop_include_shipping', '$webshop_payment_processor', '$webshop_payment_processor_account', '$webshop_limit', '$webshop_imagewidth', '$id');";
         else
            $sql = "UPDATE CMS_WEBSHOP SET webshop_enabled='$webshop_enabled', webshop_title='$webshop_title', webshop_email='$webshop_email', webshop_currency_sign='$webshop_currency_sign', webshop_include_shipping='$webshop_include_shipping', webshop_payment_processor='$webshop_payment_processor', webshop_payment_processor_account='$webshop_payment_processor_account', webshop_limit='$webshop_limit', webshop_imagewidth='$webshop_imagewidth' WHERE page_id='$id'";
         mysql_query($sql, $db) or die(mysql_error());
      }
   }
}

?>