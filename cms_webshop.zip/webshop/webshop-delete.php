<?php
   global $db;
   if (isset($_REQUEST['webshopid']))
   {
      $sql = "DELETE FROM CMS_WEBSHOP_PRODUCTS WHERE id=".$_REQUEST['webshopid'];
      mysql_query($sql, $db) or die(mysql_error());
   }
?>